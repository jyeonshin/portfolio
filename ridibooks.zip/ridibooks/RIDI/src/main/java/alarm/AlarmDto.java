package alarm;

public class AlarmDto {
	String imageUrl;
	String title;
	String aTagUrl;
	public String getImageUrl() {
		return imageUrl;
	}
	public void setImageUrl(String imageUrl) {
		this.imageUrl = imageUrl;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getaTagUrl() {
		return aTagUrl;
	}
	public void setaTagUrl(String aTagUrl) {
		this.aTagUrl = aTagUrl;
	}
}
