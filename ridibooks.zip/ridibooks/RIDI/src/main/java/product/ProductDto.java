package product;

public class ProductDto {

}
